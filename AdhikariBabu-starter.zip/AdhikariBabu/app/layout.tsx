import "./globals.css";
export const metadata = {
  title:"AdhikariBabu — Government Jobs, Results & Exams",
  description:"Government jobs, results, admit cards, answer keys and career information."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}