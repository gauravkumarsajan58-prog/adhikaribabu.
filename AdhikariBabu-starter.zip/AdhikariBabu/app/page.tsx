import Header from "@/components/Header";
import SectionTitle from "@/components/SectionTitle";
import MobileNav from "@/components/MobileNav";
import { ArrowRight, BellRing, CalendarDays, GraduationCap, MapPin, Building2, IndianRupee, FileText, Trophy, BookOpen, Search } from "lucide-react";

const jobs=[
 {dept:"Government Department",name:"Recruitment 2026",posts:"450 Posts",qual:"Graduation",place:"All India"},
 {dept:"Public Sector",name:"Latest Government Vacancy",posts:"237 Posts",qual:"12th Pass",place:"Bihar"},
 {dept:"Railway",name:"Railway Recruitment 2026",posts:"1,200 Posts",qual:"10th / ITI",place:"All India"}
];
const important=[
 ["Application Open","SSC Recruitment 2026","Apply before 28 Sep","blue"],
 ["Exam Upcoming","Railway Examination","Exam: 05 Oct","amber"],
 ["Result Available","BPSC Result 2026","Check Result","green"]
];
export default function Home(){
 return <><Header/>
 <main className="pb-16 md:pb-0">
  <section className="bg-gradient-to-b from-[#eef4ff] to-[#f6f8fc] py-12 sm:py-16"><div className="container text-center">
   <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-xs font-bold text-blue-700 shadow-sm"><BellRing size={15}/> Trusted career updates</div>
   <h1 className="text-4xl font-black tracking-tight text-[#0b1f4b] sm:text-6xl">Your Career. Your Next Opportunity.</h1>
   <p className="mx-auto mt-4 max-w-2xl text-sm leading-6 text-slate-600 sm:text-base">Government jobs, results, exams & career information — all in one place.</p>
   <div className="mx-auto mt-7 flex max-w-2xl items-center rounded-2xl border bg-white p-2 shadow-soft"><Search className="ml-2 text-slate-400" size={21}/><input className="min-w-0 flex-1 bg-transparent px-3 py-3 outline-none" placeholder="Search jobs, exams..."/><button className="rounded-xl bg-blue-600 px-5 py-3 font-bold text-white">Search</button></div>
   <div className="mt-4 flex flex-wrap justify-center gap-2 text-xs text-slate-500">Popular: {["SSC","Railway","UPSC","Bihar","Banking"].map(x=><span key={x} className="rounded-full bg-white px-3 py-1.5 font-semibold shadow-sm">{x}</span>)}</div>
  </div></section>

  <section className="section"><div className="container"><div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
   {[["Jobs","/jobs"],["Results","/results"],["Admit Card","/admit-card"],["Answer Key","/answer-key"]].map(([x,u])=><a key={x} href={u} className="card flex items-center justify-between p-4 font-extrabold hover:-translate-y-0.5"><span>{x}</span><ArrowRight size={18} className="text-blue-600"/></a>)}
  </div></div></section>

  <section className="pb-4"><div className="container"><SectionTitle title="🔥 Today’s Important"/><div className="grid gap-3 md:grid-cols-3">
   {important.map(([badge,title,sub,color])=><div className="card p-5" key={title}><span className={`inline-block rounded-full px-3 py-1 text-xs font-bold ${color==="blue"?"bg-blue-50 text-blue-700":color==="amber"?"bg-amber-50 text-amber-700":"bg-emerald-50 text-emerald-700"}`}>{badge}</span><h3 className="mt-4 font-extrabold">{title}</h3><p className="mt-1 text-sm text-slate-500">{sub}</p></div>)}
  </div></div></section>

  <section className="section"><div className="container"><SectionTitle title="💼 Latest Job Opportunities" action="View All Jobs"/><div className="grid gap-4 md:grid-cols-3">
   {jobs.map(j=><article className="card p-5" key={j.name}><p className="text-xs font-bold text-blue-600">{j.dept}</p><h3 className="mt-2 text-lg font-extrabold">{j.name}</h3><p className="mt-2 font-bold">{j.posts}</p><div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-600"><span className="flex items-center gap-1 rounded-lg bg-slate-50 px-2 py-1"><GraduationCap size={14}/>{j.qual}</span><span className="flex items-center gap-1 rounded-lg bg-slate-50 px-2 py-1"><MapPin size={14}/>{j.place}</span></div><a className="mt-5 inline-flex items-center gap-1 text-sm font-bold text-blue-600" href="/jobs">View details <ArrowRight size={15}/></a></article>)}
  </div><div className="mt-4 flex gap-2 overflow-x-auto hide-scroll">{["All","10th","12th","Graduate","Bihar","All India"].map(x=><button key={x} className="whitespace-nowrap rounded-full border bg-white px-4 py-2 text-sm font-semibold text-slate-600">{x}</button>)}</div></div></section>

  <section className="section bg-white"><div className="container"><SectionTitle title="🎯 Find Jobs Your Way"/><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
   {[["By Qualification",GraduationCap,"12th Pass → All Government Jobs"],["By State",MapPin,"Bihar → Latest Opportunities"],["By Organization",Building2,"SSC → Latest Updates"],["By Salary",IndianRupee,"Best salary opportunities"]].map(([t,I,d])=>{const Icon=I as any;return <div className="card p-5" key={t as string}><Icon className="text-blue-600"/><h3 className="mt-4 font-extrabold">{t as string}</h3><p className="mt-2 text-sm text-slate-500">{d as string}</p></div>})}
  </div></div></section>

  <section className="section"><div className="container"><SectionTitle title="📅 Exam Calendar" action="View Calendar"/><div className="card divide-y overflow-hidden">{[["18","SEP","SSC CGL","Application Closing"],["22","SEP","Railway","CBT Examination"],["28","SEP","BPSC","Application Closing"]].map(x=><div className="flex items-center gap-4 p-4" key={x[0]}><div className="w-14 text-center"><div className="text-2xl font-black text-[#0b1f4b]">{x[0]}</div><div className="text-xs font-bold text-slate-400">{x[1]}</div></div><div><div className="font-extrabold">{x[2]}</div><div className="text-sm text-slate-500">{x[3]}</div></div></div>)}</div></div></section>

  <section className="section bg-white"><div className="container grid gap-5 lg:grid-cols-2">
   {[["📊 Latest Results",["BPSC Result 2026","SSC Result 2026","Railway Result"]],["🎫 Admit Cards",["SSC Admit Card","Railway Admit Card","BPSC Admit Card"]]].map(([title,items])=><div className="card p-5" key={title as string}><SectionTitle title={title as string} action="View All"/>{(items as string[]).map(i=><a href="#" key={i} className="flex items-center justify-between border-b py-3 last:border-0"><span className="font-semibold">{i} →</span><Trophy size={17} className="text-blue-500"/></a>)}</div>)}
  </div></section>

  <section className="section"><div className="container"><SectionTitle title="🏢 Explore Organizations"/><div className="flex flex-wrap gap-3">{["SSC","UPSC","Railway","Banking","Defence","PSU","State PSC","Police","Teaching"].map(x=><a href="#" className="card px-5 py-3 font-bold text-slate-700" key={x}>{x}</a>)}</div></div></section>
  <section className="section bg-white"><div className="container"><SectionTitle title="📍 State-wise Opportunities"/><div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{["Bihar","Uttar Pradesh","Jharkhand","West Bengal","Delhi","Maharashtra","Rajasthan","Madhya Pradesh"].map(x=><a href="#" className="card p-4 font-bold" key={x}>{x}</a>)}</div></div></section>
  <section className="section"><div className="container"><SectionTitle title="📚 Career Resources"/><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">{["Government Forms","Syllabus","Previous Papers","Exam Pattern","Career Guides"].map(x=><div className="card p-5 font-bold" key={x}><BookOpen className="mb-3 text-blue-600" size={21}/>{x}</div>)}</div></div></section>
  <section className="section bg-white"><div className="container"><SectionTitle title="⭐ Featured / Sponsored"/><div className="card flex min-h-24 items-center justify-between p-5"><div><p className="text-xs font-bold text-blue-600">FEATURED</p><h3 className="mt-1 font-extrabold">Your trusted career resource</h3><p className="text-sm text-slate-500">Sponsored content will appear here.</p></div><ArrowRight className="text-blue-600"/></div></div></section>
  <section className="section"><div className="container"><SectionTitle title="📰 Latest Updates" action="View All"/><div className="card divide-y">{["New government recruitment announced...","Result released for latest examination...","New examination schedule published..."].map((x,i)=><div className="p-4" key={x}><div className="text-xs font-bold text-slate-400">{15-i} Sep • Recruitment</div><div className="mt-1 font-semibold">{x}</div></div>)}</div></div></section>
 </main>
 <footer className="border-t bg-[#0b1f4b] py-10 text-white"><div className="container grid gap-8 sm:grid-cols-2"><div><div className="text-xl font-black">ADHIKARIBABU</div><p className="mt-2 text-sm text-slate-300">Government Jobs • Results • Exams</p></div><div className="text-sm text-slate-300"><p>Jobs • Results • Admit Cards • Answer Keys</p><p className="mt-3">About Us • Contact • Privacy Policy • Disclaimer</p><p className="mt-4">© 2026 AdhikariBabu</p></div></div></footer>
 <MobileNav/></>
}