import { Bell, Menu, Moon, Search } from "lucide-react";
export default function Header(){
 return <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
  <div className="container flex h-16 items-center justify-between gap-3">
   <div className="flex items-center gap-2"><button className="rounded-lg p-2 hover:bg-slate-100 md:hidden" aria-label="menu"><Menu size={22}/></button>
    <div className="flex items-center gap-2"><div className="grid h-9 w-9 place-items-center rounded-xl bg-blue-600 font-black text-white">A</div><span className="text-lg font-extrabold text-[#0b1f4b]">AdhikariBabu</span></div>
   </div>
   <nav className="hidden items-center gap-6 text-sm font-semibold text-slate-600 md:flex">
    <a href="/jobs">Jobs</a><a href="/results">Results</a><a href="/admit-card">Admit Card</a><a href="/answer-key">Answer Key</a><a href="/exam-calendar">Calendar</a><a href="#more">More</a>
   </nav>
   <div className="flex items-center gap-1"><button className="rounded-lg p-2 hover:bg-slate-100" aria-label="search"><Search size={19}/></button><button className="rounded-lg p-2 hover:bg-slate-100" aria-label="notifications"><Bell size={19}/></button><button className="hidden rounded-lg p-2 hover:bg-slate-100 sm:block" aria-label="dark mode"><Moon size={19}/></button></div>
  </div>
 </header>
}